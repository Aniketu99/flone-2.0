let singleItemId;

window.onload = () => {
    singleItemId = JSON.parse(localStorage.getItem("singleItemId"));
    showData();
};

//function to fetch data from Api
async function fetchData(start, end) {

    const url = `https://raw.githubusercontent.com/nitinpatil77/JsonData/main/product.json?`;

    try {

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }

        const collection = await response.json();
        return collection.slice(start, end);

    } catch (error) {

        console.error('Error fetching data:', error);
    }

}

async function showData() {

    let products = await fetchData(0, 30);
    let singlePage = document.getElementById("singlePage");

    products.forEach((product) => {
        let { id, name, price, discount, newP, rating, product_main_img, subDescrption } = product;
        const discountedPrice = price - price * (discount / 100);

        if (id === singleItemId) {

            singlePage.innerHTML = `
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="product-large-image-wrapper position-relative">
                        <div class="product-img-badges">
                        ${discount
                    ? `<span class="pink">${discount}%</span>`
                    : ""
                }
                        ${newP
                    ? `<span class="purple">${newP}</span>`
                    : ""
                }
                        </div>
                        <div class="swiper-wrap">
                            <div class="single-image"><img src="${product_main_img[0]}" class="img-fluid" alt=""></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="product-details-content ml-70">
                        <h2>${name}</h2>
                        <div class="product-details-price">
                         ${discount ? `<span class="new">$${discountedPrice.toFixed(2)}</span>` : ""
                } 
                          ${discount ? `<span class="old">$${price}</span>` : `<span class="new">$${price}</span>`
                }   
                          
                        </div>
                        <div class="pro-details-rating-wrap">
                            <div class="pro-details-rating">
                                ${generateStars(rating)}
                            </div>
                        </div>
                        <div class="pro-details-list">
                            <p>${subDescrption}</p>
                        </div>
                        <div class="pro-details-size-color d-flex">
                            <div class="pro-details-color-wrap">
                                <span>Color</span>
                                <div class="pro-details-color-content">
                                    <label class="pro-details-color-content--single white">
                                        <input type="radio" name="product-color" value="white" checked="">
                                        <span class="checkmark"></span>
                                    </label>
                                    <label class="pro-details-color-content--single black">
                                        <input type="radio" name="product-color" value="black">
                                        <span class="checkmark"></span>
                                    </label>
                                    <label class="pro-details-color-content--single brown">
                                        <input type="radio" name="product-color" value="brown">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="pro-details-size">
                                <span>Size</span>
                                <div class="pro-details-size-content">
                                    <label class="pro-details-size-content--single">
                                        <input type="radio" value="x" checked="">
                                        <span class="size-name">x</span>
                                    </label>
                                    <label class="pro-details-size-content--single">
                                        <input type="radio" value="m">
                                        <span class="size-name">m</span>
                                    </label>
                                    <label class="pro-details-size-content--single">
                                        <input type="radio" value="xl">
                                        <span class="size-name">xl</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="pro-details-quality">
                            <div class="cart-plus-minus">
                                <button class="dec qtybutton">-</button>
                                <input class="cart-plus-minus-box" type="text" readonly="" value="1">
                                <button class="inc qtybutton">+</button>
                            </div>
                            <div class="pro-details-cart btn-hover">
                                <button onclick="addToCart(${id})"> Add To Cart </button>
                            </div>
                            <div class="pro-details-wishlist">
                                <button class="" title="Add to wishlist">
                                    <i class="bi bi-suit-heart"></i>
                                </button>
                            </div>
                            <div class="pro-details-compare">
                                <button class="" title="Add to compare">
                                    <i class="bi bi-shuffle"></i>
                                </button>
                            </div>
                        </div>
                        <div class="pro-details-meta d-flex">
                            <span>Categories :</span>
                            <ul>
                                <li><a href="#">fashion</a></li>
                                <li><a href="#">men</a></li>
                            </ul>
                        </div>
                        <div class="pro-details-meta d-flex">
                            <span>Tags :</span>
                            <ul><li><a href="#">fashion</a></li>
                                <li><a href="#">men</a></li>
                                <li><a href="#">jacket</a></li>
                                <li><a href="#">full sleeve</a></li>
                            </ul>
                        </div>
                        <div class="pro-details-social">
                            <ul class="d-flex">
                                <li>
                                    <a href="//facebook.com"><i class="fa-brands fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="//dribbble.com"><i class="fa-brands fa-dribbble"></i></a>
                                </li>
                                <li>
                                    <a href="//pinterest.com"><i class="fa-brands fa-pinterest-p"></i></a>
                                </li>
                                <li>
                                    <a href="//twitter.com"><i class="fa-brands fa-x-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="//linkedin.com"><i class="fa-brands fa-linkedin-in"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            `
        }
    });
}


//genrate start function 
function generateStars(rating) {

    const filledStars = Math.floor(rating);  //filled star
    const halfStar = rating - filledStars >= 0.5 ? 1 : 0; //half star
    const emptyStars = 5 - filledStars - halfStar; // empty star

    let starsHTML = "";
    for (let i = 0; i < filledStars; i++) {
        starsHTML += `<i class="fa-regular fa-star" style="color: #ffa900;"></i>`;
    }
    if (halfStar) {
        starsHTML += `<i class="fa-regular fa-star-half-alt" style="color: #ffa900;"></i>`;
    }
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += `<i class="far fa-star"></i>`;
    }

    return starsHTML; //return all star
}

